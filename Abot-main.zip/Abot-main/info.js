exports.info = (id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) => {
	return `
  
❉──────────❉
  Hi. *${id.split("@s.whatsapp.net")[0]}* 👋️
❉──────────❉

         ───
📆 *${tampilTanggal}*
⏱️ *${tampilWaktu}*
📢 Bot Aktif ; *${aktif}*
         ───
         
-----------------------------------
 *About ${A187}*
-----------------------------------
|   *⚠️WARNING⚠️*
|
|
| *TIDAK BOLEH
|  *MENGGANTI INFO!!!*
|
├≽️⚜ *AUTHOR*: AdityaGanZ
├≽️⚜ *DESIGNER*: AdityaGanZ
├≽️⚜ *YOUTUBE*: AdityaGanZ
|
|___________________________
|  *${A187}*
|____________________________
──❉ *SOSMED ADMIN* ❉──
│1. *Group WhatsApp*
│ _${groupwhatsapp}_
│2. *YouTube <subscribe>*
│ _${youtube}_
│3. *Instagram <Follow>*
│ _${instagram}_
│4. *Creator ${A187}*
│ _${nomer}_
╰───────────
|_______________________________
|_*MADE BY ADITYA*_
|_______________________________
}
